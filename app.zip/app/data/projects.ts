export type Project = {
  slug: string
  title: string
  description: string
  stack: string[]
  status: "idea" | "in-progress" | "done"
  content: string
}

export const projects: Project[] = [
  {
    slug: "drip-locker",
    title: "Drip Locker",
    description: "E-commerce web app for sneakers and streetwear.",
    stack: ["Laravel", "React", "MySQL", "REST API"],
    status: "in-progress",
    content: "Full description of Drip Locker project..."
  },
  {
    slug: "dev-lab-portfolio",
    title: "Dev Lab Portfolio",
    description: "This portfolio built with Next.js and TypeScript.",
    stack: ["Next.js", "TS", "Tailwind"],
    status: "in-progress",
    content: "Full description of Dev Lab portfolio..."
  },
  {
    slug: "js-utilities",
    title: "JS Practice Projects",
    description: "Small JavaScript utilities and learning experiments.",
    stack: ["JavaScript", "Git"],
    status: "idea",
    content: "Description of JS utilities..."
  }
]
